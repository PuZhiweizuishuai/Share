* test
    * test
        * test

+ test
    + test
        + test

- test
    - test
      - test

1. test
    1. test
        1. test

1) test
    1) test
        1) test

* [ ] test
    * [ ] test
        * [ ] test

+ [ ] test
    + [ ] test
        + [ ] test

- [ ] test
    - [ ] test
        - [ ] test
