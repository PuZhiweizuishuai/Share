```
<textarea>
    <div>test</div>
</textarea>
```

<: \&lt; `&lt;`
\>: \&gt; `&gt;`
