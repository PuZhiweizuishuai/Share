# 安全报告 Security report

如果你发现安全相关漏洞请通过如下任意一种方式告知我们：\
If you find security-related vulnerabilities, please inform us in any of the following ways:

* 直接开 Issue（请隐去站点、实际项目等敏感信息）\
  Open Issue directly (please hide sensitive information such as site and actual project)
* 发邮件至 845765@qq.com\
  Send an email to 845765@qq.com
* 在链滴上[私信我](https://ld246.com/chats/88250) \
  On the LianDi [Private Message](https://ld246.com/chats/88250)

非常感谢！\
Thank you very much!
